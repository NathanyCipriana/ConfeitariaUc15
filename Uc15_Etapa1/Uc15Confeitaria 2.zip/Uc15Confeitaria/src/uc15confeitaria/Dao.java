
package uc15confeitaria;

import java.util.ArrayList;
import java.util.List;


public class Dao {
    private List<Produto> produto;
    
    public Dao(){
        produto= new ArrayList<>();
    }
    
    public void AdicionarProduto(Produto p){
        produto.add(p);
    }
    
    public void listarProdutos() {
        for (Produto p : produto) {
            System.out.println("ID: " + p.getIdProduto() + " Nome do produto: " + p.getNomeProduto() +" Descrição: "+p.getDescricao() + "Valor: R$" + p.getValor());
            System.out.println("--------------------------------------");
        }
    }
}
