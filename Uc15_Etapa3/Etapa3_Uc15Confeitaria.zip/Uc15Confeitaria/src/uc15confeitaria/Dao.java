
package uc15confeitaria;

import java.awt.Image;
import java.util.ArrayList;
import java.util.List;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import telas.TelaCadastroCliente;
import telas.TelaLogin;      

public class Dao {
    private List<Produto> produto;
    
    public Dao(){
        produto= new ArrayList<>();
       
    }
    
    public void AdicionarProduto(Produto p){
        produto.add(p);
    }
    
    public void listarProdutos() {
        for (Produto p : produto) {
            System.out.println("ID: " + p.getIdProduto() + " Nome do produto: " + p.getNomeProduto() +" Descrição: "+p.getDescricao() + "Valor: R$" + p.getValor());
            System.out.println("--------------------------------------");
        }
    }    
       
}
