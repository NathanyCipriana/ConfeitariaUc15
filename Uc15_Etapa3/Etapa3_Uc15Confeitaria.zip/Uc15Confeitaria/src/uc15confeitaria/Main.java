
package uc15confeitaria;


public class Main {
    public static void main (String[] args){
        System.out.println("Bem-vindo a Confeitaria da Fatima!");
        
        Dao dao= new Dao();
        
        System.out.println("-- Produtos disponíveis --");
        dao.AdicionarProduto(new Produto(1,"Bolo de pote,\n ","Nozes, \n", 10.0));
        dao.AdicionarProduto(new Produto(2,"Trufas,\n "," Sortidas \n", 3.50));
    
        dao.listarProdutos();
    }
}
