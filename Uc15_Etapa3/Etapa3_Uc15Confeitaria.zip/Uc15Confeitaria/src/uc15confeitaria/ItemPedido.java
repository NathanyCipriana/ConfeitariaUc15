
package uc15confeitaria;

public class ItemPedido {
    int idPedido;
    public String quantidade;
    public double valorTotal;
    public Pedido pedido;
    public String nomeProduto;
    public Produto produto;

    public ItemPedido() {
    }

    public ItemPedido(int idPedido, String quantidade, double valorTotal, Pedido pedido, String nomeProduto, Produto produto) {
        this.idPedido = idPedido;
        this.quantidade = quantidade;
        this.valorTotal = valorTotal;
        this.pedido = pedido;
        this.nomeProduto = nomeProduto;
        this.produto = produto;
    }

    public int getIdPedido() {
        return idPedido;
    }

    public void setIdPedido(int idPedido) {
        this.idPedido = idPedido;
    }

    public String getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(String quantidade) {
        this.quantidade = quantidade;
    }

    public double getValorTotal() {
        return valorTotal;
    }

    public void setValorTotal(double valorTotal) {
        this.valorTotal = valorTotal;
    }

    public Pedido getPedido() {
        return pedido;
    }

    public void setPedido(Pedido pedido) {
        this.pedido = pedido;
    }

    public String getNomeProduto() {
        return nomeProduto;
    }

    public void setNomeProduto(String nomeProduto) {
        this.nomeProduto = nomeProduto;
    }

    public Produto getProduto() {
        return produto;
    }

    public void setProduto(Produto produto) {
        this.produto = produto;
    }
    
    
}
